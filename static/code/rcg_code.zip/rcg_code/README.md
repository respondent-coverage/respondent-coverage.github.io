# RCG / OSR evaluation code

- [Overview](#overview)
- [Installation](#installation)
- [Quick start with toy data](#quick-start-with-toy-data)
- [Input files](#input-files)
- [Commands and outputs](#commands-and-outputs)
- [Definitions](#definitions)
- [Settings used in the paper](#settings-used-in-the-paper)
- [Python API](#python-api)
- [Tests](#tests)
- [Files](#files)

## Overview

This package evaluates generated survey responses (for example, answers produced by an LLM for personas)
against human survey responses, separately for each conditioning cell (a group of humans defined by
their attributes). For every cell and every set of generated respondents it computes:

- **RCG** (respondent coverage gap): how far the humans of the cell are from their nearest generated
  respondent, relative to how far they are from one another. RCG > 1 means that part of the human
  population is not covered by the generated respondents.
- **OSR** (off-support ratio): how far the generated respondents are from their nearest human, relative to
  the same human reference. OSR > 1 means that some generated respondents lie off the human support.
- **Calibrated RCG** (the paper's "Cal."): RCG after rewriting the generated answers item by item so that
  every item's answer distribution matches the human one (the RCG that remains reflects how answers are
  combined across items).

It also fits the statistical baselines of the paper (**Marginals**, **Copula**, **LCA**) to the humans of
each cell and samples synthetic respondents from them, so that they can be evaluated in the same way.

The package assumes that the human responses and the generated responses are already collected and coded.
It does not include the code that queries LLMs, the preprocessing of the survey data (item selection,
recoding, construction of the cells), or the scripts for the tables and figures. The survey data are not
redistributed; they are available from their official distributors.

## Installation

Python 3.12 was used (the pinned versions need Python 3.11 or later). The dependencies are pinned to the
versions used for the paper.

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e ".[test]"
```

## Quick start with toy data

```bash
python examples/make_toy_data.py --out-dir toy
python -m rcg baselines --schema toy/schema.jsonl --human toy/human.jsonl --cells toy/cells.jsonl \
    --out-dir toy/generated
python -m rcg evaluate --schema toy/schema.jsonl --human toy/human.jsonl --cells toy/cells.jsonl \
    --generated collapsed=toy/generated_collapsed.jsonl \
    --generated shifted=toy/generated_shifted.jsonl \
    --generated marginal=toy/generated/marginal.jsonl \
    --generated copula=toy/generated/copula.jsonl \
    --generated lca=toy/generated/lca.jsonl \
    --calibration dm --out-dir toy/results
```

The toy humans come from a latent class model; `collapsed` is a low-diversity generator and `shifted` pushes
answers to the top of their scales. With the pinned versions we obtained:

```text
generator  n_cells   rcg   osr  rcg_dm
collapsed        4 1.522 0.620   1.093
  shifted        4 1.296 1.295   1.057
 marginal        4 1.079 1.061   1.083
   copula        4 1.059 1.066   1.063
      lca        4 1.060 1.040   1.051
```

The low-diversity generator has a high RCG but an OSR below 1 (its respondents are close to humans, but many
humans have no generated respondent nearby); the shifted generator has a high OSR.

## Input files

All input files are JSON Lines (one JSON object per line). Answers are integer codes; `null` or an absent
item is a missing answer (the code -999 is reserved for missing answers). Other keys, such as respondent
attributes, are ignored, but an answer to an item that is not in the schema is an error. Identifiers may be
strings or integers; they are compared as strings.

**Schema** (`--schema`): one line per item, in the column order used by the distance.

```json
{"item": "q01", "type": "ordinal", "range": 4}
{"item": "q15", "type": "nominal"}
```

| key | content |
| --- | --- |
| `item` | name of the item in `answers` |
| `type` | `numeric`, `ordinal`, `nominal` or `binary_asym` |
| `range` | range of the item for the Gower distance (numeric and ordinal items) |

If the range of a numeric or ordinal item is omitted (or null), the observed range of the human answers is
used and a warning is printed. The paper fixed the ranges from the response options (see
[Settings used in the paper](#settings-used-in-the-paper)).

**Human respondents** (`--human`): one line per respondent.

```json
{"respondent_id": "h001", "answers": {"q01": 3, "q02": null, "q15": 2}}
```

**Cells** (`--cells`): one line per cell, with the ids of its human respondents. A respondent may belong to
several cells.

```json
{"cell_id": "x1-group-A", "respondent_ids": ["h001", "h004", "h007"]}
```

**Generated respondents** (`--generated NAME=PATH`, repeatable): one line per generated respondent.

```json
{"cell_id": "x1-group-A", "answers": {"q01": 4, "q02": 1, "q15": 2}}
```

The first 100 generated respondents of a cell are used; a cell with fewer is skipped for that generator.
Generated respondents of a cell that is not in the cells file are ignored (with a warning).

Reproducibility conventions:

- Within a cell, the humans are used in the order of `respondent_ids` and the generated respondents in file
  order; the random draws depend on these orders.
- The random draws of a cell depend on its index, the position of its `cell_id` in the sorted list of all
  cell ids of the cells file. The same set of cells gives the same draws.
- The calibration draws also depend on the generator name given with `--generated`.

## Commands and outputs

`python -m rcg baselines` fits each baseline to all humans of each cell and writes
`<out-dir>/<baseline>.jsonl` in the format of the generated respondents (100 per cell by default;
`--n-samples`).
Options: `--baselines marginal,copula,lca`, `--seed 0`, `--lca-n-components 2`, `--n-jobs -1`.

`python -m rcg evaluate` writes two CSV files to `--out-dir`:

- `cells.csv`: one row per cell and generator with `n_human`, `n_generated`, `n_repeats`, `rcg`, `rcg_std`
  and `osr`, `osr_std` (standard deviations over the repetitions), with `--calibration dm` also `rcg_dm`,
  `rcg_dm_std` (over the calibrations) and `n_fallback_dm` (answers left unchanged because the item has no
  observed answer on one side), and `skipped_reason` (empty when the pair was evaluated).
- `summary.csv`: per generator, the number of evaluated cells and the means over those cells (each cell has
  the same weight).

Options: `--calibration dm` (default: none), `--n-repeats 50`, `--n-calibration-reps 20`,
`--fixed-size 100`, `--quantile 0.95`, `--seed 0`, `--n-jobs -1`.

`--n-jobs` sets the number of worker processes over cells; the metrics do not depend on it. Where
multiprocessing is not available, use `--n-jobs 1`.

## Definitions

**Gower distance.** For two respondents x and y, only the items answered by both contribute:

```text
d(x, y) = mean over common items j of d_j(x_j, y_j)
  numeric, ordinal : d_j = min(|x_j - y_j| / range_j, 1)
  nominal          : d_j = 0 if x_j = y_j, else 1
  binary_asym      : like nominal, but items where both values are 0 are skipped
```

A pair without a common item has no distance and is ignored when taking nearest neighbours.

**RCG and OSR of a cell.** Let H be the humans of the cell (at least 100; otherwise the cell is skipped)
and G the first 100 generated respondents. Each repetition r = 1, ..., R (R = 50; R = 1 when H has exactly
100 humans) draws H100, a random subset of 100 humans, and computes, with Q the 0.95 quantile:

```text
ref_r = Q over h in H100 of min over h' in H100, h' != h, of d(h, h')
rcg_r = (Q over h in H100 of min over g in G of d(h, g)) / ref_r
osr_r = (Q over g in G of min over h in H100 of d(g, h)) / ref_r
```

RCG and OSR are the means of rcg_r and osr_r over the repetitions. Both are 1 when the generated respondents
are as close to the humans as the humans are to one another (at the 0.95 quantile).

**Calibration** (`--calibration dm`; the paper's "Cal."). For every item, the answers of G are rewritten
with a random rule M(b | a) that makes the item's answer distribution equal to that of all humans of the
cell (missing answers stay missing). Numeric and ordinal items use quantile mapping (the monotone
rearrangement); nominal and binary_asym items use minimum-rewrite remapping, which keeps the common mass in
place and moves the answers in excess to the answers in deficit.

The calibrated RCG of a cell is the mean over 20 independent calibrations, each evaluated with the same H100
draws as the uncalibrated RCG.

**Baselines.** Each baseline is fitted to all humans of the cell and samples 100 respondents:

- `marginal`: every item drawn independently from its human answer distribution.
- `copula`: rank-based Gaussian copula; the correlation of the normal scores of the ranks is estimated with
  Ledoit-Wolf shrinkage, and the samples are mapped back through the empirical quantiles of each item.
- `lca`: latent class model with 2 classes (stepmix, categorical measurement, 3 initializations); samples are
  snapped to the nearest observed answer of each item.

Copula and LCA are fitted to the humans who answered every item. When a cell has fewer than 50 of them, all
humans are used with missing answers filled by the item median (a warning reports the number of such cells).

## Settings used in the paper

- The defaults of the commands: 100 humans per draw and 100 generated respondents per cell, R = 50
  repetitions, the 0.95 quantile, seed 0, 20 calibrations, the baseline settings above.
- The numbers in the paper are means over cells of the per-cell values.
- Inputs (prepared by code that is not included):
    - The schema lists the items sorted by their identifiers.
    - Ordinal items are coded by the rank of the response option (0, ..., K - 1) with range K - 1; numeric
      scales keep their codes, with the range of the scale (maximum minus minimum).
    - Answers such as "don't know", and answers outside the response options, are missing.
    - Humans with fewer than 10 answered items (out of 100) are excluded.

The metrics and the Marginals baseline are reproduced exactly from the same inputs. The Copula and LCA
baselines depend on numerical libraries (BLAS, stepmix); with other versions or builds their samples may
differ.

## Python API

```python
import numpy as np
from rcg import evaluate_cell, generate_baseline

# human: (n_human, D) integer answers of one cell, -999 = missing
# llm:   (100, D) integer answers generated for the same cell
# col_types: D type names; ranges: D item ranges (NaN for nominal items)
marginal = generate_baseline("marginal", human, 100, cell_index=0)
result = evaluate_cell(
    human, {"llm": llm, "marginal": marginal}, col_types, ranges,
    cell_index=0, calibration=("dm",),
)
print(result["llm"]["rcg"], result["llm"]["osr"], result["llm"]["rcg_dm"])
```

## Tests

```bash
pytest
```

The tests check the input files, the distance on hand-computed cases, the calibration constraint (the implied
answer distribution equals the human one), the behaviour of RCG and OSR on synthetic generators, the
baselines, and the command line interface on the toy data.

## Files

| file | content |
| --- | --- |
| `rcg/gower.py` | Gower distance (numba) |
| `rcg/metrics.py` | RCG, OSR and calibrated RCG of one cell |
| `rcg/calibration.py` | per-item calibration operators |
| `rcg/baselines.py` | Marginals, Copula and LCA baselines |
| `rcg/io.py` | input files (JSON Lines) |
| `rcg/cli.py` | command line interface (`python -m rcg`) |
| `examples/make_toy_data.py` | toy data |
| `tests/` | tests |
