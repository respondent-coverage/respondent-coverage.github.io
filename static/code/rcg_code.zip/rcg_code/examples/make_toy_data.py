"""Write a small synthetic data set in the input format of ``python -m rcg``.

    python examples/make_toy_data.py --out-dir toy/

Files (JSON Lines, one object per line):

- ``schema.jsonl``: 20 items (8 ordinal with 5 options coded 0-4, 6 numeric
  scales coded 0-10, 6 nominal items coded 1-4)
- ``human.jsonl``: 900 synthetic humans drawn from a 3-class latent class
  model whose class shares depend on a group attribute (A, B, C); 3% of the
  answers are missing (null). The group is kept as an extra key, which the
  package ignores.
- ``cells.jsonl``: everyone ("x0-all") and each group ("x1-group-A", ...),
  so every human belongs to two cells.
- ``generated_collapsed.jsonl``: 100 generated respondents per cell that all
  come from the cell's most common latent class and mostly give its modal
  answers (a low-diversity generator: RCG > 1).
- ``generated_shifted.jsonl``: 100 generated respondents per cell whose
  ordinal and numeric answers are pushed to the top of their scales (many of
  them are far from every human: OSR > 1).
"""

import argparse
import json
from collections.abc import Iterable
from pathlib import Path

import numpy as np

N_PER_GROUP = 300
GROUPS = ("A", "B", "C")
N_GENERATED = 100
TYPES = ["ordinal"] * 8 + ["numeric"] * 6 + ["nominal"] * 6
CODES = {"ordinal": np.arange(0, 5), "numeric": np.arange(0, 11), "nominal": np.arange(1, 5)}
RANGES = {"ordinal": 4, "numeric": 10, "nominal": None}
CLASS_SHARES = {"A": [0.6, 0.3, 0.1], "B": [0.2, 0.6, 0.2], "C": [0.1, 0.3, 0.6]}
MISSING_RATE = 0.03


def class_distributions(rng: np.random.Generator) -> list[list[np.ndarray]]:
    """Answer distribution of every item in each of the 3 latent classes."""
    out = []
    for _ in range(3):
        per_item = []
        for t in TYPES:
            alpha = np.full(CODES[t].size, 0.4)
            per_item.append(rng.dirichlet(alpha))
        out.append(per_item)
    return out


def sample_rows(rng, dists, classes: np.ndarray, modal_prob: float = 0.0) -> np.ndarray:
    """Answers of respondents in the given latent classes.

    With probability ``modal_prob`` an answer is the class's modal answer,
    otherwise it is drawn from the class distribution.
    """
    out = np.empty((classes.size, len(TYPES)), dtype=int)
    for j, t in enumerate(TYPES):
        for c in range(3):
            rows = np.where(classes == c)[0]
            if rows.size == 0:
                continue
            p = dists[c][j]
            draws = rng.choice(CODES[t], size=rows.size, p=p)
            modal = rng.random(rows.size) < modal_prob
            draws[modal] = CODES[t][int(np.argmax(p))]
            out[rows, j] = draws
    return out


def answer_dict(items: list[str], row: np.ndarray, missing: np.ndarray | None = None) -> dict:
    """{item: code} of one respondent; missing answers are null."""
    return {
        item: None if missing is not None and missing[j] else int(row[j])
        for j, item in enumerate(items)
    }


def write_jsonl(path: Path, records: Iterable[dict]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record) + "\n")


def make_toy(out_dir: Path, seed: int = 0) -> None:
    rng = np.random.default_rng(seed)
    dists = class_distributions(rng)
    items = [f"q{j + 1:02d}" for j in range(len(TYPES))]
    out_dir.mkdir(parents=True, exist_ok=True)
    write_jsonl(
        out_dir / "schema.jsonl",
        ({"item": item, "type": t, "range": RANGES[t]} for item, t in zip(items, TYPES, strict=True)),
    )

    groups = np.repeat(GROUPS, N_PER_GROUP)
    classes = np.concatenate([rng.choice(3, size=N_PER_GROUP, p=CLASS_SHARES[g]) for g in GROUPS])
    answers = sample_rows(rng, dists, classes)
    missing = rng.random(answers.shape) < MISSING_RATE
    ids = [f"h{i + 1:03d}" for i in range(groups.size)]
    write_jsonl(
        out_dir / "human.jsonl",
        (
            {"respondent_id": rid, "group": str(g), "answers": answer_dict(items, row, miss)}
            for rid, g, row, miss in zip(ids, groups, answers, missing, strict=True)
        ),
    )

    cells = {"x0-all": np.ones(groups.size, dtype=bool)}
    cells.update({f"x1-group-{g}": groups == g for g in GROUPS})
    write_jsonl(
        out_dir / "cells.jsonl",
        (
            {"cell_id": cid, "respondent_ids": [rid for rid, m in zip(ids, mask, strict=True) if m]}
            for cid, mask in cells.items()
        ),
    )

    collapsed, shifted = [], []
    for cid, mask in cells.items():
        top_class = int(np.bincount(classes[mask], minlength=3).argmax())
        rows = sample_rows(rng, dists, np.full(N_GENERATED, top_class), modal_prob=0.8)
        collapsed += [{"cell_id": cid, "answers": answer_dict(items, row)} for row in rows]
        cell_classes = rng.choice(classes[mask], size=N_GENERATED)
        rows = sample_rows(rng, dists, cell_classes)
        for j, t in enumerate(TYPES):
            if t != "nominal":
                top = CODES[t][-1]
                rows[:, j] = np.where(rng.random(N_GENERATED) < 0.5, top, rows[:, j])
        shifted += [{"cell_id": cid, "answers": answer_dict(items, row)} for row in rows]
    write_jsonl(out_dir / "generated_collapsed.jsonl", collapsed)
    write_jsonl(out_dir / "generated_shifted.jsonl", shifted)


def main() -> None:
    parser = argparse.ArgumentParser(description="Write a small synthetic data set for python -m rcg")
    parser.add_argument("--out-dir", type=Path, default=Path("toy"))
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    make_toy(args.out_dir, seed=args.seed)
    print(f"wrote schema.jsonl, human.jsonl, cells.jsonl, generated_collapsed.jsonl, "
          f"generated_shifted.jsonl to {args.out_dir}")


if __name__ == "__main__":
    main()
