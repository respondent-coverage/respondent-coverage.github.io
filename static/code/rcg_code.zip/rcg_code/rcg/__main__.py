from rcg.cli import main

raise SystemExit(main())
