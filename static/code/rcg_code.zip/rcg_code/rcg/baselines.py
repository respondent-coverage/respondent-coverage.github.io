"""Statistical baselines fitted to the human respondents of one cell.

Each baseline is fitted to all humans of a cell and samples ``n_samples``
synthetic respondents (integer answers, never missing):

- ``marginal`` (the paper's "Marginals"): every item is drawn independently
  from the cell's human answer distribution of that item.
- ``copula`` (the paper's "Copula"): a rank-based Gaussian copula. The
  dependence is the correlation of the normal scores of the ranks, estimated
  with Ledoit-Wolf shrinkage (with about 100 humans and 100 items the sample
  correlation is singular); each item is mapped back through the empirical
  quantiles of the human answers, so only observed answers are produced.
- ``lca`` (the paper's "LCA"): a latent class model (mixture of categorical
  distributions, 2 classes) fitted with ``stepmix``; samples are snapped to
  the nearest observed answer of each item.

Copula and LCA are fitted to the complete cases (humans who answered every
item). When a cell has fewer than ``COMPLETE_CASE_MIN`` complete cases, the
missing answers are filled with the item median instead and all humans are
used; ``n_complete_cases`` lets the caller count these cells.

Seeds: the baseline of a cell uses ``cell_seed(seed, baseline, cell_index)``,
as in the paper's pipeline.
"""

import logging

import numpy as np
import pandas as pd

MISSING = -999
BASELINES = ("marginal", "copula", "lca")
COMPLETE_CASE_MIN = 50
LCA_N_COMPONENTS = 2

# Per-baseline entry of the seed sequence (kept from the paper's pipeline).
_SEED_OFFSETS = {"marginal": 0, "copula": 60, "lca": 61}

logger = logging.getLogger(__name__)


def cell_seed(seed: int, baseline: str, cell_index: int) -> int:
    """Deterministic non-negative int32 seed of (seed, baseline, cell)."""
    ss = np.random.SeedSequence([seed, _SEED_OFFSETS[baseline], cell_index])
    return int(ss.generate_state(1)[0] & 0x7FFFFFFF)


def n_complete_cases(human_raw: np.ndarray) -> int:
    """Number of humans who answered every item."""
    return int((np.asarray(human_raw) != MISSING).all(axis=1).sum())


def _column_value_distributions(human_raw: np.ndarray) -> list[tuple[np.ndarray, np.ndarray]]:
    """(observed answers, probabilities) of every item; missing excluded."""
    out = []
    for j in range(human_raw.shape[1]):
        col = human_raw[:, j]
        valid = col[col != MISSING]
        if valid.size == 0:
            out.append((np.array([MISSING], dtype=int), np.array([1.0])))
            continue
        codes, counts = np.unique(valid, return_counts=True)
        out.append((codes.astype(int), counts.astype(float) / counts.sum()))
    return out


def sample_marginal(human_raw: np.ndarray, n_samples: int, seed: int) -> np.ndarray:
    """Draw every item independently from its human answer distribution."""
    rng = np.random.default_rng(seed)
    distributions = _column_value_distributions(human_raw)
    out = np.empty((n_samples, len(distributions)), dtype=int)
    for j, (codes, probs) in enumerate(distributions):
        out[:, j] = rng.choice(codes, size=n_samples, p=probs)
    return out


def _complete_cases_or_median_fill(human_raw: np.ndarray) -> np.ndarray:
    """Complete cases; with too few of them, all rows with median-filled gaps."""
    df = pd.DataFrame(human_raw)
    mask_clean = (df != MISSING).all(axis=1)
    if int(mask_clean.sum()) < COMPLETE_CASE_MIN:
        df = df.replace(MISSING, np.nan)
        df = df.fillna(df.median(numeric_only=True))
        return np.asarray(df.values)
    return np.asarray(df[mask_clean].values)


def _snap_to_valid_codes(samples: np.ndarray, human_raw: np.ndarray) -> np.ndarray:
    """Snap every sampled value to the nearest observed human answer of its item."""
    n_samples, D = samples.shape
    out = np.empty((n_samples, D), dtype=int)
    for j in range(D):
        col = human_raw[:, j]
        valid = col[col != MISSING]
        if valid.size == 0:
            out[:, j] = MISSING
            continue
        codes = np.unique(valid).astype(int)
        diff = np.abs(samples[:, j : j + 1] - codes[None, :])
        out[:, j] = codes[np.argmin(diff, axis=1)]
    return out


def sample_copula(
    human_raw: np.ndarray,
    n_samples: int,
    seed: int,
    ties: str = "average",
    shrinkage: str | None = "ledoit_wolf",
) -> np.ndarray:
    """Rank-based Gaussian copula with empirical marginals.

    1. Ranks of every item -> pseudo-observations u = rank / (n + 1).
    2. Normal scores z = Phi^{-1}(u); their correlation matrix is the
       dependence (Ledoit-Wolf shrinkage by default; None = sample
       correlation).
    3. Multivariate normal samples -> Phi -> inverse empirical CDF of each
       item (so only observed answers appear).

    Items without variation are filled with their only value.
    """
    from scipy.stats import norm, rankdata

    if shrinkage not in (None, "ledoit_wolf"):
        raise ValueError(f"unknown shrinkage={shrinkage!r}; use None or 'ledoit_wolf'")

    train = _complete_cases_or_median_fill(human_raw).astype(int)
    n, D = train.shape
    var_pos_mask = train.max(axis=0) > train.min(axis=0)
    pos_idx = np.where(var_pos_mask)[0]
    out = np.empty((n_samples, D), dtype=int)
    rng = np.random.default_rng(seed)

    if pos_idx.size < 2:
        for j in range(D):
            sorted_j = np.sort(train[:, j])
            u = rng.uniform(size=n_samples)
            idx = np.clip(np.ceil(u * n).astype(int) - 1, 0, n - 1)
            out[:, j] = sorted_j[idx]
        return out

    train_pos = train[:, pos_idx]
    n_pos, D_pos = train_pos.shape
    pobs = np.empty_like(train_pos, dtype=float)
    for j in range(D_pos):
        pobs[:, j] = rankdata(train_pos[:, j], method=ties) / (n_pos + 1)
    z = norm.ppf(pobs)
    if shrinkage == "ledoit_wolf":
        from sklearn.covariance import LedoitWolf

        cov = np.asarray(LedoitWolf().fit(z).covariance_)
        diag_sqrt = np.sqrt(np.diag(cov))
        sigma = cov / np.outer(diag_sqrt, diag_sqrt)
    else:
        sigma = np.corrcoef(z, rowvar=False)
    sigma = 0.5 * (sigma + sigma.T)
    sigma = sigma + 1e-10 * np.eye(D_pos)

    chol = np.linalg.cholesky(sigma)
    g = rng.standard_normal((n_samples, D_pos))
    u_pos = norm.cdf(g @ chol.T)
    for col_local, j in enumerate(pos_idx):
        sorted_j = np.sort(train[:, j])
        idx = np.clip(np.ceil(u_pos[:, col_local] * n).astype(int) - 1, 0, n - 1)
        out[:, j] = sorted_j[idx]
    for j in np.where(~var_pos_mask)[0]:
        out[:, j] = int(train[0, j])
    return out


def _stepmix_sklearn_compat_shim() -> None:
    """Provide ``BaseEstimator._validate_data`` for stepmix 2.2 on scikit-learn >= 1.6.

    Not needed with the pinned scikit-learn (< 1.6); kept so that a newer
    scikit-learn does not break the LCA baseline.
    """
    import sklearn.base

    if hasattr(sklearn.base.BaseEstimator, "_validate_data"):
        return
    from sklearn.utils.validation import (
        validate_data,  # pyright: ignore[reportAttributeAccessIssue]
    )

    def _compat_validate_data(self, *args, **kwargs):
        return validate_data(self, *args, **kwargs)

    sklearn.base.BaseEstimator._validate_data = _compat_validate_data  # pyright: ignore[reportAttributeAccessIssue]


def sample_lca(
    human_raw: np.ndarray,
    n_samples: int,
    seed: int,
    n_components: int = LCA_N_COMPONENTS,
) -> np.ndarray:
    """Latent class model (mixture of categorical distributions) fit and sample."""
    from stepmix.stepmix import StepMix

    _stepmix_sklearn_compat_shim()
    train_mat = _complete_cases_or_median_fill(human_raw)
    model = StepMix(
        n_components=n_components,
        measurement="categorical",
        n_init=3,
        random_state=seed,
        progress_bar=0,
    )
    model.fit(train_mat)
    # StepMix.sample does not take a random state; it draws from numpy's
    # global generator, which is seeded here.
    np.random.seed(seed)
    out = model.sample(n_samples=n_samples)
    samples = np.asarray(out[0]) if isinstance(out, tuple) else np.asarray(out)
    if samples.dtype.kind != "i":
        samples = samples.astype(int)
    return _snap_to_valid_codes(samples.astype(float), human_raw)


def generate_baseline(
    baseline: str,
    human_raw: np.ndarray,
    n_samples: int,
    *,
    cell_index: int,
    seed: int = 0,
    lca_n_components: int = LCA_N_COMPONENTS,
) -> np.ndarray:
    """Fit one baseline to the humans of a cell and sample from it."""
    if baseline not in BASELINES:
        raise ValueError(f"unknown baseline {baseline!r}; expected one of {BASELINES}")
    human_raw = np.asarray(human_raw)
    s = cell_seed(seed, baseline, cell_index)
    if baseline == "marginal":
        return sample_marginal(human_raw, n_samples, seed=s)
    if baseline == "copula":
        return sample_copula(human_raw, n_samples, seed=s, shrinkage="ledoit_wolf")
    return sample_lca(human_raw, n_samples, seed=s, n_components=lca_n_components)
