"""Per-item marginal calibration of generated responses within a cell.

The calibration (operator ``dm``, the paper's "Cal.") rewrites the answers of
the generated respondents item by item so that, for every item, the
distribution of the rewritten answers matches the distribution of the cell's
human answers. The rule for one item is a row-stochastic matrix M(b | a): an
answer a is replaced by b with probability M(b | a), and

    sum_a p_G(a) M(b | a) = p_H(b)    for every b,

where p_G and p_H are the generated and human answer distributions of the
item (missing answers excluded; they stay missing). The constraint leaves M
underdetermined; the rule is

- for ordered items (numeric / ordinal), quantile mapping: the monotone
  rearrangement, an optimal transport plan for the cost |a - b|;
- for unordered items, minimum-rewrite remapping: an optimal transport plan
  for the cost 1[a != b], which keeps the common mass min(p_G, p_H) in place
  and sends the excess to the deficient answers in proportion to the
  deficits.

Because the calibration matches the per-item marginals, the RCG that remains
after calibration reflects how the generated respondents combine their
answers across items.
"""

import hashlib

import numpy as np

MISSING = -999

# Operator name -> label of its random stream. The label is the name the
# paper's pipeline used for this transform; it enters the seed of the random
# stream, so keeping it reproduces the paper's draws.
OPERATORS = {"dm": "calibrate_incell"}
ORDERED_COL_TYPES = frozenset({"ordinal", "numeric"})

# Fixed entry of the seed sequence that separates the calibration streams from
# the H100 draws (which use [seed, cell_index, rep]).
_CALIBRATION_STREAM = 971

CalibrationMap = dict[int, tuple[np.ndarray, np.ndarray]]


def stream_key(generator: str, label: str, rep: int) -> int:
    """Stable integer key of (generator, operator, repetition) for the seed."""
    digest = hashlib.sha256(f"{generator}|{label}|{rep}".encode()).digest()
    return int.from_bytes(digest[:8], "little")


def calibration_rng(seed: int, cell_index: int, generator: str, operator: str, rep: int):
    """Random generator of one calibration repetition."""
    label = OPERATORS[operator]
    return np.random.default_rng(
        np.random.SeedSequence(
            [seed, cell_index, _CALIBRATION_STREAM, stream_key(generator, label, rep)],
        ),
    )


def learn_calibration_map(
    g_col: np.ndarray,
    h_col: np.ndarray,
    ordered: bool,
) -> CalibrationMap | None:
    """Learn the rule M(b | a) of one item: {a: (target codes, probabilities)}.

    Quantile mapping when ``ordered``, minimum-rewrite remapping otherwise.
    Returns None when either side has no observed answer (the item is then
    left unchanged and counted as a fallback).
    """
    g = g_col[g_col != MISSING]
    h = h_col[h_col != MISSING]
    if g.size == 0 or h.size == 0:
        return None
    gv, gc = np.unique(g, return_counts=True)
    hv, hc = np.unique(h, return_counts=True)
    pg = gc / g.size
    ph = hc / h.size
    m: CalibrationMap = {}
    if ordered:
        # Quantile mapping: split the CDF interval [F_G(a-), F_G(a)] of each
        # generated answer a at the human CDF breakpoints; the overlaps are
        # the probabilities.
        fg_hi = np.cumsum(pg)
        fg_lo = fg_hi - pg
        fh_hi = np.cumsum(ph)
        fh_lo = fh_hi - ph
        for a_idx, a in enumerate(gv):
            ov = np.minimum(fg_hi[a_idx], fh_hi) - np.maximum(fg_lo[a_idx], fh_lo)
            ov = np.clip(ov, 0.0, None)
            tot = float(ov.sum())
            if tot <= 0.0:  # numerical corner case (interval of zero mass)
                m[int(a)] = (np.asarray([a], dtype=np.int64), np.asarray([1.0]))
                continue
            probs = ov / tot
            keep = probs > 0
            m[int(a)] = (hv[keep].astype(np.int64), probs[keep])
        return m
    # Minimum-rewrite remapping (0-1 cost optimal transport): keep
    # min(p_G, p_H) in place and send the excess of each answer to the
    # deficient answers in proportion to the deficits.
    all_v = np.union1d(gv, hv)
    pg_full = np.zeros(all_v.size)
    pg_full[np.searchsorted(all_v, gv)] = pg
    ph_full = np.zeros(all_v.size)
    ph_full[np.searchsorted(all_v, hv)] = ph
    deficit = np.clip(ph_full - pg_full, 0.0, None)
    d_tot = float(deficit.sum())
    for i, a in enumerate(all_v):
        if pg_full[i] <= 0.0:
            continue
        probs = np.zeros(all_v.size)
        probs[i] = min(pg_full[i], ph_full[i]) / pg_full[i]
        excess_i = max(pg_full[i] - ph_full[i], 0.0)
        if excess_i > 0.0 and d_tot > 0.0:
            probs += (excess_i / pg_full[i]) * (deficit / d_tot)
        probs = probs / probs.sum()
        keep = probs > 0
        m[int(a)] = (all_v[keep].astype(np.int64), probs[keep])
    return m


def learn_calibration_maps(
    g_raw: np.ndarray,
    human_raw: np.ndarray,
    ordered_cols: list[bool],
) -> list[CalibrationMap | None]:
    """Learn the rules of all items (columns)."""
    return [
        learn_calibration_map(g_raw[:, j], human_raw[:, j], ordered_cols[j])
        for j in range(g_raw.shape[1])
    ]


def apply_calibration(
    g_raw: np.ndarray,
    maps: list[CalibrationMap | None],
    rng: np.random.Generator,
) -> tuple[np.ndarray, int]:
    """Rewrite a copy of g_raw with the rules; return it and the fallback count.

    Missing answers stay missing. An answer without a rule (its item had no
    observed answer on one side) is left unchanged and counted as a fallback.
    """
    out = g_raw.copy()
    n_fallback = 0
    for j, m in enumerate(maps):
        col = g_raw[:, j]
        valid_mask = col != MISSING
        if not valid_mask.any():
            continue
        if m is None:
            n_fallback += int(valid_mask.sum())
            continue
        for a in np.unique(col[valid_mask]):
            rows = np.where(col == a)[0]
            rule = m.get(int(a))
            if rule is None:
                n_fallback += rows.size
                continue
            codes, probs = rule
            if codes.size == 1:
                out[rows, j] = codes[0]
            else:
                out[rows, j] = rng.choice(codes, size=rows.size, p=probs)
    return out, n_fallback


def calibrate(
    g_raw: np.ndarray,
    human_raw: np.ndarray,
    col_types,
    operator: str,
    rng: np.random.Generator,
) -> tuple[np.ndarray, int]:
    """Calibrate the generated matrix of a cell to the cell's human answers.

    Args:
        g_raw: (n_gen, D) integer answers of the generated respondents
            (``MISSING`` = missing).
        human_raw: (n_human, D) integer answers of all humans in the cell.
        col_types: (D,) column type names.
        operator: a key of ``OPERATORS`` ("dm").
        rng: random generator (see ``calibration_rng``).
    """
    if operator not in OPERATORS:
        raise ValueError(f"unknown operator {operator!r}; expected one of {sorted(OPERATORS)}")
    ordered_cols = [str(t) in ORDERED_COL_TYPES for t in np.asarray(col_types, dtype=object)]
    maps = learn_calibration_maps(g_raw, human_raw, ordered_cols)
    return apply_calibration(g_raw, maps, rng)
