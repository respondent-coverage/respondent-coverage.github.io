"""Command line interface of the RCG / OSR evaluation.

    python -m rcg baselines --schema schema.jsonl --human human.jsonl --cells cells.jsonl \\
        --out-dir generated/
    python -m rcg evaluate --schema schema.jsonl --human human.jsonl --cells cells.jsonl \\
        --generated llm=llm.jsonl --generated marginal=generated/marginal.jsonl \\
        --calibration dm --out-dir results/

See the README for the file formats and the meaning of the outputs.
"""

import argparse
import logging
import os
import sys
from collections import Counter
from collections.abc import Iterable
from pathlib import Path
from typing import cast

import numpy as np
import pandas as pd
from joblib import Parallel, delayed, effective_n_jobs, parallel_config
from tqdm import tqdm
from tqdm.contrib.logging import logging_redirect_tqdm

from rcg.baselines import (
    BASELINES,
    COMPLETE_CASE_MIN,
    LCA_N_COMPONENTS,
    generate_baseline,
    n_complete_cases,
)
from rcg.calibration import OPERATORS
from rcg.gower import observed_ranges
from rcg.io import (
    Schema,
    cell_matrices,
    read_cells,
    read_generated,
    read_respondents,
    read_schema,
    write_generated,
)
from rcg.metrics import (
    FIXED_SIZE,
    N_CALIBRATION_REPS,
    N_REPEATS,
    QUANTILE,
    evaluate_cell,
    to_float,
)

logger = logging.getLogger("rcg")


def _workers(n_jobs: int, n_tasks: int) -> int:
    if n_jobs == 1 or n_tasks <= 1:
        return 1
    return max(1, min(effective_n_jobs(n_jobs), n_tasks))


def _parallel(n_workers: int):
    """joblib context that splits the CPUs between the worker processes.

    The Gower kernel is multi-threaded (numba); each worker gets
    cpu_count // n_workers threads so that the machine is not oversubscribed.
    """
    if n_workers <= 1:
        return parallel_config(backend="sequential")
    threads = max(1, (os.cpu_count() or 1) // n_workers)
    return parallel_config(backend="loky", inner_max_num_threads=threads)


def _load_inputs(args) -> tuple[Schema, dict[str, np.ndarray], dict[str, int]]:
    schema = read_schema(args.schema)
    respondents = read_respondents(args.human, schema.items)
    cells = read_cells(args.cells)
    human = cell_matrices(respondents, cells)
    # The cell index (part of every seed) is the position in the sorted cell ids.
    cell_index = {cid: i for i, cid in enumerate(sorted(human))}
    logger.info("schema: %d items; humans: %d respondents; cells: %d (%d memberships)",
                len(schema.items), len(respondents), len(human),
                sum(m.shape[0] for m in human.values()))
    n_outside = len(set(respondents).difference(*cells.values()))
    if n_outside:
        logger.info("%d human respondents are in no cell", n_outside)
    return schema, human, cell_index


def _resolve_ranges(schema: Schema, human: dict[str, np.ndarray]) -> np.ndarray:
    """Ranges from the schema; observed human ranges where the schema has none."""
    ranges = schema.ranges.copy()
    numeric_like = np.isin(schema.col_types.astype(str), ["numeric", "ordinal"])
    need = numeric_like & np.isnan(ranges)
    if need.any():
        pooled = to_float(np.vstack(list(human.values())))
        ranges[need] = observed_ranges(pooled, schema.col_types)[need]
        logger.warning(
            "%d numeric / ordinal items have no range in the schema; using the observed "
            "range of the human answers for them (the paper fixes ranges from the response "
            "options; see the README)", int(need.sum()),
        )
    return ranges


def _baseline_task(
    baseline: str, cell_id: str, human_raw: np.ndarray, n_samples: int,
    cell_index: int, seed: int, lca_n_components: int,
) -> tuple[str, str, np.ndarray | None, str | None]:
    try:
        mat = generate_baseline(
            baseline, human_raw, n_samples, cell_index=cell_index, seed=seed,
            lca_n_components=lca_n_components,
        )
    except Exception as exc:  # reported in the summary of cmd_baselines
        return baseline, cell_id, None, f"{type(exc).__name__}: {exc}"
    return baseline, cell_id, mat, None


def cmd_baselines(args) -> int:
    schema, human, cell_index = _load_inputs(args)
    baselines = [b.strip() for b in args.baselines.split(",") if b.strip()]
    unknown = [b for b in baselines if b not in BASELINES]
    if unknown:
        raise SystemExit(f"unknown baselines {unknown}; expected some of {BASELINES}")
    cells = sorted(human)
    tasks = [(b, cid) for b in baselines for cid in cells]

    n_workers = _workers(args.n_jobs, len(tasks))
    out: dict[str, dict[str, np.ndarray]] = {b: {} for b in baselines}
    failed: Counter[str] = Counter()
    with _parallel(n_workers), logging_redirect_tqdm():
        results = cast(
            Iterable[tuple[str, str, np.ndarray | None, str | None]],
            Parallel(n_jobs=n_workers, return_as="generator")(
                delayed(_baseline_task)(
                    b, cid, human[cid], args.n_samples, cell_index[cid], args.seed,
                    args.lca_n_components,
                )
                for b, cid in tasks
            ),
        )
        for b, cid, mat, err in tqdm(results, total=len(tasks), desc="baselines"):
            if mat is None:
                failed[b] += 1
                logger.warning("baseline %s failed in cell %s: %s", b, cid, err)
            else:
                out[b][cid] = mat
    args.out_dir.mkdir(parents=True, exist_ok=True)
    for b in baselines:
        write_generated(args.out_dir / f"{b}.jsonl", out[b], schema.items)

    fallback = [cid for cid in cells if n_complete_cases(human[cid]) < COMPLETE_CASE_MIN]
    if fallback and ({"copula", "lca"} & set(baselines)):
        logger.warning(
            "%d / %d cells have fewer than %d complete cases; copula / lca were fitted to "
            "all humans with median-filled gaps there", len(fallback), len(cells), COMPLETE_CASE_MIN,
        )
    if failed:
        logger.warning("failed (baseline, cell) fits: %s", dict(failed))
    print(f"wrote {', '.join(f'{b}.jsonl' for b in baselines)} to {args.out_dir} "
          f"({len(cells)} cells, {args.n_samples} rows per cell)")
    return 1 if failed else 0


def _parse_generated(specs: list[str]) -> dict[str, Path]:
    out: dict[str, Path] = {}
    for spec in specs:
        name, sep, path = spec.partition("=")
        if not sep or not name or not path:
            raise SystemExit(f"--generated expects NAME=PATH, got {spec!r}")
        if name in out:
            raise SystemExit(f"duplicated generator name {name!r}")
        out[name] = Path(path)
    return out


def _evaluate_task(
    cell_id: str, human_raw: np.ndarray, gen_mats: dict[str, np.ndarray | None],
    col_types: np.ndarray, ranges: np.ndarray, cell_index: int, params: dict,
) -> tuple[str, dict[str, dict]]:
    return cell_id, evaluate_cell(
        human_raw, gen_mats, col_types, ranges, cell_index=cell_index, **params,
    )


def cmd_evaluate(args) -> int:
    schema, human, cell_index = _load_inputs(args)
    ranges = _resolve_ranges(schema, human)
    calibration = [c.strip() for c in args.calibration.split(",") if c.strip()]
    unknown = [c for c in calibration if c not in OPERATORS]
    if unknown:
        raise SystemExit(f"unknown calibration operators {unknown}; expected some of {sorted(OPERATORS)}")
    generated: dict[str, dict[str, np.ndarray]] = {}
    for name, path in _parse_generated(args.generated).items():
        generated[name] = read_generated(path, schema.items)
        extra = sorted(set(generated[name]) - set(human))
        if extra:
            logger.warning("generator %s: %d cells are not in the cells file and are ignored",
                           name, len(extra))
        n_truncated = sum(
            m.shape[0] > args.fixed_size for cid, m in generated[name].items() if cid in human
        )
        if n_truncated:
            logger.warning("generator %s: %d cells have more than %d rows; the first %d are used",
                           name, n_truncated, args.fixed_size, args.fixed_size)

    params = {
        "seed": args.seed,
        "n_repeats": args.n_repeats,
        "fixed_size": args.fixed_size,
        "quantile": args.quantile,
        "calibration": calibration,
        "n_calibration_reps": args.n_calibration_reps,
    }
    cells = sorted(human)
    n_workers = _workers(args.n_jobs, len(cells))
    rows: list[dict] = []
    with _parallel(n_workers), logging_redirect_tqdm():
        results = cast(
            Iterable[tuple[str, dict[str, dict]]],
            Parallel(n_jobs=n_workers, return_as="generator")(
                delayed(_evaluate_task)(
                    cid, human[cid], {name: generated[name].get(cid) for name in generated},
                    schema.col_types, ranges, cell_index[cid], params,
                )
                for cid in cells
            ),
        )
        for cid, res in tqdm(results, total=len(cells), desc="evaluate"):
            for name, row in res.items():
                rows.append({"cell_id": cid, "generator": name, **row})

    columns = ["cell_id", "generator", "n_human", "n_generated", "n_repeats",
               "rcg", "rcg_std", "osr", "osr_std"]
    for op in calibration:
        columns += [f"rcg_{op}", f"rcg_{op}_std", f"n_fallback_{op}"]
    columns.append("skipped_reason")
    table = pd.DataFrame(rows, columns=pd.Index(columns))
    table = table.sort_values(["generator", "cell_id"], kind="stable")

    value_cols = ["rcg", "osr", *[f"rcg_{op}" for op in calibration]]
    evaluated = table[table["skipped_reason"] == ""]
    summary = pd.DataFrame(
        [
            {
                "generator": name,
                "n_cells": int((evaluated["generator"] == name).sum()),
                **{c: evaluated.loc[evaluated["generator"] == name, c].astype(float).mean()
                   for c in value_cols},
            }
            for name in generated
        ],
    )
    args.out_dir.mkdir(parents=True, exist_ok=True)
    table.to_csv(args.out_dir / "cells.csv", index=False, float_format="%.10g")
    summary.to_csv(args.out_dir / "summary.csv", index=False, float_format="%.10g")

    skipped = table[table["skipped_reason"] != ""]
    if len(skipped):
        reasons = Counter(str(r).split("=")[0] for r in skipped["skipped_reason"])
        logger.warning("skipped (generator, cell) pairs: %d (%s)", len(skipped), dict(reasons))
    cell_sets = {
        frozenset(evaluated.loc[evaluated["generator"] == name, "cell_id"]) for name in generated
    }
    if len(cell_sets) > 1:
        logger.warning("generators were evaluated on different cell sets; their means are "
                       "not over the same cells (see cells.csv)")
    for op in calibration:
        n_fb = int(np.nansum(np.asarray(evaluated[f"n_fallback_{op}"], dtype=float)))
        if n_fb:
            logger.warning("calibration %s left %d answers unchanged (no rule for them)", op, n_fb)
    with pd.option_context("display.float_format", "{:.3f}".format, "display.width", 120):
        print(summary.to_string(index=False))
    print(f"wrote cells.csv and summary.csv to {args.out_dir}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="rcg", description="RCG / OSR evaluation of generated survey responses")
    sub = parser.add_subparsers(dest="command", required=True)

    def common(p: argparse.ArgumentParser) -> None:
        p.add_argument("--schema", required=True, type=Path, help="item schema (JSON Lines)")
        p.add_argument("--human", required=True, type=Path, help="human respondents (JSON Lines)")
        p.add_argument("--cells", required=True, type=Path,
                       help="cells and the ids of their human respondents (JSON Lines)")
        p.add_argument("--out-dir", required=True, type=Path)
        p.add_argument("--seed", type=int, default=0)
        p.add_argument("--n-jobs", type=int, default=-1,
                       help="worker processes over cells (-1 = all CPUs, 1 = sequential)")

    p = sub.add_parser("baselines", help="fit the baselines to every cell and sample from them")
    common(p)
    p.add_argument("--baselines", default=",".join(BASELINES),
                   help=f"comma separated subset of {','.join(BASELINES)}")
    p.add_argument("--n-samples", type=int, default=FIXED_SIZE)
    p.add_argument("--lca-n-components", type=int, default=LCA_N_COMPONENTS)
    p.set_defaults(func=cmd_baselines)

    p = sub.add_parser("evaluate", help="RCG / OSR (and calibrated RCG) per cell and generator")
    common(p)
    p.add_argument("--generated", action="append", default=[], required=True, metavar="NAME=PATH",
                   help="generated respondents (JSON Lines; repeatable)")
    p.add_argument("--calibration", default="",
                   help=f"comma separated calibration operators ({','.join(OPERATORS)}); "
                        "empty = no calibration")
    p.add_argument("--n-repeats", type=int, default=N_REPEATS)
    p.add_argument("--n-calibration-reps", type=int, default=N_CALIBRATION_REPS)
    p.add_argument("--fixed-size", type=int, default=FIXED_SIZE)
    p.add_argument("--quantile", type=float, default=QUANTILE)
    p.set_defaults(func=cmd_evaluate)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s", stream=sys.stderr)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
