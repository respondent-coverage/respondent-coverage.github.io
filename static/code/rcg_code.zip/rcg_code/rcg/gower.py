"""Gower distance for mixed-type survey responses.

Responses are float64 matrices in which NaN marks a missing answer. For a pair
of respondents, only the items answered by both contribute (pairwise
deletion), and each item contributes a distance in [0, 1]:

- numeric / ordinal : |x_j - y_j| / range_j, clipped at 1
- nominal           : 0 if x_j == y_j else 1
- binary_asym       : like nominal, but a pair in which both values are 0
                      (both "absent") is skipped

The distance is the mean over the contributing items. A pair with no item in
common has no defined distance and gets NaN; callers decide how to treat it
(see ``rcg.metrics``).
"""

import numba
import numpy as np

COL_TYPES = ("numeric", "ordinal", "nominal", "binary_asym")

# Integer codes of the column types inside the JIT kernel.
_CODE_NUMERIC = 0
_CODE_ORDINAL = 1
_CODE_NOMINAL = 2
_CODE_BINARY_ASYM = 3


def col_type_codes(col_types) -> np.ndarray:
    """Map column type names to the int8 codes used by the kernel."""
    names = [str(t) for t in np.asarray(col_types, dtype=object).tolist()]
    unknown = sorted({t for t in names if t not in COL_TYPES})
    if unknown:
        raise ValueError(f"unknown column types {unknown}; expected one of {COL_TYPES}")
    lookup = {
        "numeric": _CODE_NUMERIC,
        "ordinal": _CODE_ORDINAL,
        "nominal": _CODE_NOMINAL,
        "binary_asym": _CODE_BINARY_ASYM,
    }
    return np.asarray([lookup[t] for t in names], dtype=np.int8)


def observed_ranges(X: np.ndarray, col_types) -> np.ndarray:
    """Observed range (max - min, ignoring NaN) of the numeric / ordinal columns.

    Nominal and binary_asym columns get NaN (no range is used for them). A
    zero or undefined range is replaced by 1.0 to avoid division by zero.

    The paper does not use observed ranges: it fixes the range of each item
    from its response options (see the README). This function is the fallback
    for items whose range is not given in the schema.
    """
    X = np.asarray(X, dtype=np.float64)
    if X.ndim != 2:
        raise ValueError(f"X must be 2D, got shape {X.shape}")
    codes = col_type_codes(col_types)
    if codes.shape != (X.shape[1],):
        raise ValueError(f"col_types has {codes.shape[0]} entries for {X.shape[1]} columns")
    out = np.full(X.shape[1], np.nan, dtype=np.float64)
    numeric_like = (codes == _CODE_NUMERIC) | (codes == _CODE_ORDINAL)
    if X.shape[0] == 0 or not numeric_like.any():
        return out
    sub = X[:, numeric_like]
    with np.errstate(invalid="ignore"):
        rng = np.nanmax(sub, axis=0) - np.nanmin(sub, axis=0)
    out[numeric_like] = np.where(np.isfinite(rng) & (rng > 0), rng, 1.0)
    return out


@numba.njit(cache=True, fastmath=False, boundscheck=False, parallel=True)
def _gower_kernel(
    X: np.ndarray,
    Y: np.ndarray,
    type_codes: np.ndarray,
    ranges: np.ndarray,
    out: np.ndarray,
) -> None:
    """Fill out[i, k] with the Gower distance between X[i] and Y[k].

    Each entry is computed by one thread with a fixed loop order over the
    items, so the result does not depend on the number of threads.
    """
    b, D = X.shape
    m = Y.shape[0]
    for i in numba.prange(b):
        for k in range(m):
            s = 0.0
            w = 0.0
            for j in range(D):
                xj = X[i, j]
                yj = Y[k, j]
                if xj != xj or yj != yj:
                    continue
                tc = type_codes[j]
                if tc == 0 or tc == 1:
                    diff = xj - yj
                    if diff < 0.0:
                        diff = -diff
                    d = diff / ranges[j]
                    if d > 1.0:
                        d = 1.0
                    s += d
                    w += 1.0
                elif tc == 2:
                    if xj != yj:
                        s += 1.0
                    w += 1.0
                elif tc == 3:
                    if xj == 0.0 and yj == 0.0:
                        continue
                    if xj != yj:
                        s += 1.0
                    w += 1.0
            if w > 0.0:
                out[i, k] = s / w
            else:
                out[i, k] = np.nan


def gower_distance(X: np.ndarray, Y: np.ndarray, col_types, ranges: np.ndarray) -> np.ndarray:
    """Gower distance matrix (n, m) between the rows of X (n, D) and Y (m, D).

    Args:
        X, Y: response matrices with NaN for missing answers.
        col_types: (D,) column type names (see ``COL_TYPES``).
        ranges: (D,) item ranges; must be finite and positive for the numeric
            and ordinal columns (ignored for the others).
    """
    X = np.ascontiguousarray(X, dtype=np.float64)
    Y = np.ascontiguousarray(Y, dtype=np.float64)
    if X.ndim != 2 or Y.ndim != 2:
        raise ValueError(f"X and Y must be 2D, got {X.shape} and {Y.shape}")
    D = X.shape[1]
    if Y.shape[1] != D:
        raise ValueError(f"column mismatch: X has {D}, Y has {Y.shape[1]}")
    codes = col_type_codes(col_types)
    ranges = np.ascontiguousarray(ranges, dtype=np.float64)
    if codes.shape != (D,) or ranges.shape != (D,):
        raise ValueError(
            f"col_types {codes.shape} and ranges {ranges.shape} must both have length {D}",
        )
    numeric_like = (codes == _CODE_NUMERIC) | (codes == _CODE_ORDINAL)
    if numeric_like.any():
        r = ranges[numeric_like]
        if not np.all(np.isfinite(r)) or np.any(r <= 0):
            raise ValueError("ranges must be finite and positive for numeric / ordinal columns")
    out = np.empty((X.shape[0], Y.shape[0]), dtype=np.float64)
    if X.shape[0] and Y.shape[0]:
        _gower_kernel(X, Y, codes, ranges, out)
    return out
