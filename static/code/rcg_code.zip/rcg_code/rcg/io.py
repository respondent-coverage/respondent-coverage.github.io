"""Reading and writing the JSON Lines files of the command line interface.

Every file has one JSON object per line. Answers are integer codes; ``null``
or an absent item is a missing answer (the code -999 is reserved for missing
answers). Keys other than the ones below are ignored, but an answer to an item
that is not in the schema is an error (usually a misspelled item name).

- Schema: one line per item, in the column order used for the distance::

      {"item": "q01", "type": "ordinal", "range": 4}

  ``type`` is numeric, ordinal, nominal or binary_asym. ``range`` is the
  range of a numeric or ordinal item for the Gower distance; it may be
  omitted or null (see ``rcg.gower.observed_ranges``).
- Human respondents: one line per respondent::

      {"respondent_id": "h001", "answers": {"q01": 3, "q02": null}}

- Cells: one line per cell, listing its human respondents::

      {"cell_id": "x1-group-A", "respondent_ids": ["h001", "h007"]}

  A respondent may belong to several cells. Within a cell, the humans are
  used in the order of ``respondent_ids`` (the random draws depend on it).
- Generated respondents: one line per generated respondent::

      {"cell_id": "x1-group-A", "answers": {"q01": 4, "q02": 1}}

  Within a cell, the lines are used in file order.

Identifiers may be strings or integers; they are compared as strings.
"""

import json
from collections.abc import Iterator, Sequence
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from rcg.gower import COL_TYPES

MISSING = -999


@dataclass
class Schema:
    items: list[str]
    col_types: np.ndarray  # (D,) object array of type names
    ranges: np.ndarray  # (D,) float64; NaN where not given


def _records(path: str | Path) -> Iterator[tuple[str, dict]]:
    """(location, object) for every non-blank line of a JSON Lines file."""
    with open(path, encoding="utf-8") as f:
        for lineno, line in enumerate(f, start=1):
            if not line.strip():
                continue
            where = f"{path}:{lineno}"
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{where}: invalid JSON ({exc.msg})") from None
            if not isinstance(record, dict):
                raise ValueError(f"{where}: each line must be a JSON object")
            yield where, record


def _as_id(value, what: str, where: str) -> str:
    if isinstance(value, bool) or not isinstance(value, (str, int)) or value == "":
        raise ValueError(f"{where}: {what} must be a non-empty string or an integer, got {value!r}")
    return str(value)


def _identifier(record: dict, key: str, where: str) -> str:
    if key not in record:
        raise ValueError(f"{where}: missing key {key!r}")
    return _as_id(record[key], key, where)


def _answer_row(record: dict, item_index: dict[str, int], where: str) -> np.ndarray:
    """(D,) int answers of one respondent; MISSING = missing."""
    answers = record.get("answers")
    if not isinstance(answers, dict):
        raise ValueError(f"{where}: 'answers' must be a JSON object of item -> integer code or null")
    row = np.full(len(item_index), MISSING, dtype=int)
    for item, value in answers.items():
        j = item_index.get(item)
        if j is None:
            raise ValueError(f"{where}: item {item!r} is not in the schema")
        if value is None:
            continue
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        if isinstance(value, bool) or not isinstance(value, int):
            raise ValueError(f"{where}: the answer to {item!r} must be an integer code or null, got {value!r}")
        if value == MISSING:
            raise ValueError(f"{where}: the code {MISSING} is reserved for missing answers (use null)")
        row[j] = value
    return row


def read_schema(path: str | Path) -> Schema:
    items: list[str] = []
    types: list[str] = []
    ranges: list[float] = []
    for where, record in _records(path):
        item = _identifier(record, "item", where)
        col_type = record.get("type")
        if col_type not in COL_TYPES:
            raise ValueError(f"{where}: unknown item type {col_type!r}; expected one of {COL_TYPES}")
        value = record.get("range")
        if value is None:
            r = np.nan
        else:
            if isinstance(value, bool) or not isinstance(value, (int, float)) \
                    or not (np.isfinite(value) and value > 0):
                raise ValueError(f"{where}: range of item {item!r} must be a positive number or null, "
                                 f"got {value!r}")
            r = float(value)
        items.append(item)
        types.append(col_type)
        ranges.append(r)
    if not items:
        raise ValueError(f"{path}: no items")
    if len(set(items)) != len(items):
        raise ValueError(f"{path}: duplicated item names")
    return Schema(
        items=items,
        col_types=np.asarray(types, dtype=object),
        ranges=np.asarray(ranges, dtype=np.float64),
    )


def read_respondents(path: str | Path, items: Sequence[str]) -> dict[str, np.ndarray]:
    """{respondent_id: (D,) int answers} in file order; MISSING = missing."""
    item_index = {item: j for j, item in enumerate(items)}
    out: dict[str, np.ndarray] = {}
    for where, record in _records(path):
        rid = _identifier(record, "respondent_id", where)
        if rid in out:
            raise ValueError(f"{where}: duplicated respondent_id {rid!r}")
        out[rid] = _answer_row(record, item_index, where)
    if not out:
        raise ValueError(f"{path}: no respondents")
    return out


def read_cells(path: str | Path) -> dict[str, list[str]]:
    """{cell_id: [respondent_id, ...]} in file order."""
    out: dict[str, list[str]] = {}
    for where, record in _records(path):
        cid = _identifier(record, "cell_id", where)
        if cid in out:
            raise ValueError(f"{where}: duplicated cell_id {cid!r}")
        members = record.get("respondent_ids")
        if not isinstance(members, list) or not members:
            raise ValueError(f"{where}: 'respondent_ids' must be a non-empty list")
        ids = [_as_id(m, "each respondent id", where) for m in members]
        if len(set(ids)) != len(ids):
            raise ValueError(f"{where}: cell {cid!r} lists a respondent more than once")
        out[cid] = ids
    if not out:
        raise ValueError(f"{path}: no cells")
    return out


def cell_matrices(answers: dict[str, np.ndarray], cells: dict[str, list[str]]) -> dict[str, np.ndarray]:
    """{cell_id: (n, D) int answers of its humans}, rows in the order of the cell's respondent ids."""
    out: dict[str, np.ndarray] = {}
    for cid, ids in cells.items():
        unknown = [rid for rid in ids if rid not in answers]
        if unknown:
            raise ValueError(f"cell {cid!r} lists {len(unknown)} respondents that are not in the "
                             f"human respondents file (e.g. {unknown[:3]})")
        out[cid] = np.vstack([answers[rid] for rid in ids])
    return out


def read_generated(path: str | Path, items: Sequence[str]) -> dict[str, np.ndarray]:
    """{cell_id: (n, D) int answers} with rows in file order; MISSING = missing."""
    item_index = {item: j for j, item in enumerate(items)}
    rows: dict[str, list[np.ndarray]] = {}
    for where, record in _records(path):
        cid = _identifier(record, "cell_id", where)
        rows.setdefault(cid, []).append(_answer_row(record, item_index, where))
    if not rows:
        raise ValueError(f"{path}: no generated respondents")
    return {cid: np.vstack(r) for cid, r in rows.items()}


def write_generated(path: str | Path, cells: dict[str, np.ndarray], items: Sequence[str]) -> None:
    """Write {cell_id: (n, D) int answers} in the generated respondents format."""
    with open(path, "w", encoding="utf-8") as f:
        for cid, mat in cells.items():
            for row in np.asarray(mat, dtype=int):
                answers = {item: (None if v == MISSING else int(v)) for item, v in zip(items, row, strict=True)}
                f.write(json.dumps({"cell_id": cid, "answers": answers}) + "\n")
