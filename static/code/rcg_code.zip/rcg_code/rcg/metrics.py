"""Respondent coverage gap (RCG) and off-support ratio (OSR) of one cell.

For one conditioning cell, let H be the human respondents of the cell and G a
set of generated respondents for the same cell (e.g. LLM responses). Each
repetition draws H100, a random subset of ``fixed_size`` (= 100) humans, and
computes three nearest-neighbour (NN) statistics with the Gower distance:

- reference      : the q-quantile (q = 0.95), over h in H100, of the distance
                   from h to its NN among the other members of H100
- RCG numerator  : the q-quantile, over h in H100, of the distance from h to
                   its NN in G
- OSR numerator  : the q-quantile, over g in G, of the distance from g to its
                   NN in H100

RCG and OSR are the numerators divided by the reference, averaged over the
repetitions. RCG > 1 means that some humans are farther from every generated
respondent than humans usually are from one another, i.e. part of the human
population is not covered. OSR > 1 means that some generated respondents are
far from every human, i.e. they lie off the human support.

Conventions (they follow the paper's pipeline; with the same inputs the
random draws and the results are reproduced exactly):

- G uses its first ``fixed_size`` rows; a generator with fewer rows is
  skipped.
- A cell with fewer than ``fixed_size`` humans is skipped. A cell with exactly
  ``fixed_size`` humans uses all of them in a single repetition.
- Repetition ``rep`` draws H100 as the first ``fixed_size`` entries of a
  permutation from
  ``np.random.default_rng(np.random.SeedSequence([seed, cell_index, rep]))``.
- A pair of respondents with no answered item in common has no distance and
  is ignored when taking NNs; a respondent without any defined distance is
  left out of the quantile.
- A repetition whose reference is not positive is left out of the average.
"""

from collections.abc import Mapping, Sequence

import numpy as np

from rcg.calibration import (
    OPERATORS,
    ORDERED_COL_TYPES,
    apply_calibration,
    calibration_rng,
    learn_calibration_maps,
)
from rcg.gower import gower_distance

MISSING = -999
FIXED_SIZE = 100
N_REPEATS = 50
QUANTILE = 0.95
N_CALIBRATION_REPS = 20


def to_float(mat: np.ndarray) -> np.ndarray:
    """Integer answers (``MISSING`` = missing) -> float64 with NaN for missing."""
    out = np.asarray(mat).astype(np.float64)
    out[out == MISSING] = np.nan
    return out


def nn_quantile(d: np.ndarray, axis: int, quantile: float) -> float:
    """q-quantile of the NN distances along ``axis`` of a distance matrix.

    Pairs without a distance (NaN) are ignored; rows (or columns) without any
    distance are left out. Returns NaN when nothing is left.
    """
    mins = np.min(np.where(np.isnan(d), np.inf, d), axis=axis)
    mins = mins[np.isfinite(mins)]
    if mins.size == 0:
        return float("nan")
    return float(np.quantile(mins, quantile))


def mean_ratio(
    nums: Sequence[float] | np.ndarray,
    denoms: Sequence[float] | np.ndarray,
) -> tuple[float | None, float | None]:
    """Mean and standard deviation of num / denom over the repetitions.

    Repetitions with a non-positive or undefined denominator, or an undefined
    ratio, are left out. Returns (None, None) when none is left.
    """
    num_arr = np.asarray(nums, dtype=np.float64)
    den_arr = np.asarray(denoms, dtype=np.float64)
    with np.errstate(divide="ignore", invalid="ignore"):
        ratios = np.where(np.isfinite(den_arr) & (den_arr > 0), num_arr / den_arr, np.nan)
    finite = ratios[np.isfinite(ratios)]
    if finite.size == 0:
        return None, None
    return float(np.mean(finite)), float(np.std(finite))


def draw_humans(
    human: np.ndarray,
    col_types,
    ranges: np.ndarray,
    *,
    cell_index: int,
    seed: int = 0,
    n_repeats: int = N_REPEATS,
    fixed_size: int = FIXED_SIZE,
    quantile: float = QUANTILE,
) -> tuple[list[np.ndarray], np.ndarray]:
    """Draw the H100 subsets of a cell and compute their reference statistic.

    Args:
        human: (n_human, D) float answers (NaN = missing), n_human >= fixed_size.

    Returns:
        (subsets, reference): the H100 matrix and the reference q-quantile of
        each repetition.
    """
    n = human.shape[0]
    if n < fixed_size:
        raise ValueError(f"need at least {fixed_size} humans, got {n}")
    reps = 1 if n == fixed_size else n_repeats
    subsets: list[np.ndarray] = []
    reference: list[float] = []
    for rep in range(reps):
        rng = np.random.default_rng(np.random.SeedSequence([seed, cell_index, rep]))
        h100 = human if n == fixed_size else human[rng.permutation(n)[:fixed_size]]
        d = gower_distance(h100, h100, col_types, ranges)
        np.fill_diagonal(d, np.inf)  # self-exclusion
        reference.append(nn_quantile(d, axis=1, quantile=quantile))
        subsets.append(h100)
    return subsets, np.asarray(reference, dtype=np.float64)


def _numerators(
    subsets: list[np.ndarray],
    gen: np.ndarray,
    col_types,
    ranges: np.ndarray,
    quantile: float,
    *,
    with_osr: bool = True,
) -> tuple[list[float], list[float]]:
    """RCG and OSR numerators of a generated matrix for every H100 subset."""
    rcg_nums: list[float] = []
    osr_nums: list[float] = []
    for h100 in subsets:
        d = gower_distance(h100, gen, col_types, ranges)
        rcg_nums.append(nn_quantile(d, axis=1, quantile=quantile))
        if with_osr:
            osr_nums.append(nn_quantile(d, axis=0, quantile=quantile))
    return rcg_nums, osr_nums


def evaluate_cell(
    human_raw: np.ndarray,
    generated: Mapping[str, np.ndarray | None],
    col_types,
    ranges: np.ndarray,
    *,
    cell_index: int,
    seed: int = 0,
    n_repeats: int = N_REPEATS,
    fixed_size: int = FIXED_SIZE,
    quantile: float = QUANTILE,
    calibration: Sequence[str] = (),
    n_calibration_reps: int = N_CALIBRATION_REPS,
) -> dict[str, dict]:
    """RCG and OSR (and optionally calibrated RCG) of every generator in a cell.

    Args:
        human_raw: (n_human, D) integer answers of all humans in the cell
            (``MISSING`` = missing), in a fixed order.
        generated: {generator name: (n_gen, D) integer answers or None}.
        col_types: (D,) column type names (see ``rcg.gower.COL_TYPES``).
        ranges: (D,) item ranges used by the Gower distance.
        cell_index: position of the cell among all cells (sorted by id); it
            enters the seed of the H100 draws.
        calibration: calibration operators (see ``rcg.calibration.OPERATORS``)
            for which the calibrated RCG is also computed.
        n_calibration_reps: number of independent calibrations; the calibrated
            RCG is their mean (each one is evaluated on the same H100 draws).

    Returns:
        {generator name: result dict}. Every result has ``n_human``,
        ``n_generated``, ``skipped_reason`` ("" when evaluated), ``rcg``,
        ``rcg_std`` (over repetitions), ``osr``, ``osr_std``, ``n_repeats``,
        and for each calibration operator ``rcg_<op>`` (mean over the
        calibrations), ``rcg_<op>_std`` (over the calibrations) and
        ``n_fallback_<op>`` (answers left unchanged for lack of a rule).
    """
    if not 0.0 < quantile <= 1.0:
        raise ValueError(f"quantile must be in (0, 1], got {quantile}")
    unknown = [op for op in calibration if op not in OPERATORS]
    if unknown:
        raise ValueError(f"unknown calibration operators {unknown}; expected {sorted(OPERATORS)}")
    human_raw = np.asarray(human_raw)
    n_human = int(human_raw.shape[0])

    results: dict[str, dict] = {}
    for name, mat in generated.items():
        n_gen = 0 if mat is None else int(np.asarray(mat).shape[0])
        row: dict = {
            "n_human": n_human,
            "n_generated": n_gen,
            "skipped_reason": "",
            "rcg": None,
            "rcg_std": None,
            "osr": None,
            "osr_std": None,
            "n_repeats": 0,
        }
        for op in calibration:
            row[f"rcg_{op}"] = None
            row[f"rcg_{op}_std"] = None
            row[f"n_fallback_{op}"] = None
        if n_human < fixed_size:
            row["skipped_reason"] = f"n_human={n_human} < {fixed_size}"
        elif mat is None:
            row["skipped_reason"] = "no generated matrix"
        elif n_gen < fixed_size:
            row["skipped_reason"] = f"n_generated={n_gen} < {fixed_size}"
        results[name] = row
    active = [name for name, row in results.items() if not row["skipped_reason"]]
    if not active:
        return results

    subsets, reference = draw_humans(
        to_float(human_raw), col_types, ranges,
        cell_index=cell_index, seed=seed, n_repeats=n_repeats,
        fixed_size=fixed_size, quantile=quantile,
    )
    ordered_cols = [str(t) in ORDERED_COL_TYPES for t in np.asarray(col_types, dtype=object)]
    for name in active:
        row = results[name]
        g_raw = np.asarray(generated[name])[:fixed_size]
        rcg_nums, osr_nums = _numerators(subsets, to_float(g_raw), col_types, ranges, quantile)
        row["n_repeats"] = len(subsets)
        row["rcg"], row["rcg_std"] = mean_ratio(rcg_nums, reference)
        row["osr"], row["osr_std"] = mean_ratio(osr_nums, reference)
        for op in calibration:
            # The rules are deterministic; only their application is random.
            maps = learn_calibration_maps(g_raw, human_raw, ordered_cols)
            values: list[float] = []
            n_fallback = 0
            for t_rep in range(n_calibration_reps):
                rng = calibration_rng(seed, cell_index, name, op, t_rep)
                g_cal, n_fb = apply_calibration(g_raw, maps, rng)
                n_fallback += n_fb
                nums, _ = _numerators(
                    subsets, to_float(g_cal), col_types, ranges, quantile, with_osr=False,
                )
                value, _ = mean_ratio(nums, reference)
                if value is not None:
                    values.append(value)
            if values:
                arr = np.asarray(values, dtype=np.float64)
                row[f"rcg_{op}"] = float(arr.mean())
                row[f"rcg_{op}_std"] = float(arr.std())
            row[f"n_fallback_{op}"] = n_fallback
    return results
