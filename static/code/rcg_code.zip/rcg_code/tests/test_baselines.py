import numpy as np
import pytest

from rcg.baselines import (
    BASELINES,
    COMPLETE_CASE_MIN,
    MISSING,
    cell_seed,
    generate_baseline,
    n_complete_cases,
)


def human_matrix(seed=0, n=200, missing=0.0):
    rng = np.random.default_rng(seed)
    latent = rng.integers(0, 2, size=n)
    out = np.empty((n, 10), dtype=int)
    for j in range(10):
        out[:, j] = np.where(latent == 1, rng.integers(3, 5, size=n), rng.integers(0, 2, size=n))
    out[rng.random(out.shape) < missing] = MISSING
    return out


@pytest.mark.parametrize("baseline", BASELINES)
def test_shape_codes_and_reproducibility(baseline):
    human = human_matrix(missing=0.02)
    a = generate_baseline(baseline, human, 100, cell_index=3)
    b = generate_baseline(baseline, human, 100, cell_index=3)
    assert a.shape == (100, 10)
    np.testing.assert_array_equal(a, b)
    assert not np.any(a == MISSING)
    for j in range(10):
        observed = set(human[:, j][human[:, j] != MISSING].tolist())
        assert set(a[:, j].tolist()) <= observed


def test_marginal_breaks_the_dependence_copula_keeps_it():
    human = human_matrix(n=600)
    corr_h = np.corrcoef(human[:, 0], human[:, 1])[0, 1]
    m = generate_baseline("marginal", human, 2000, cell_index=0)
    c = generate_baseline("copula", human, 2000, cell_index=0)
    assert abs(np.corrcoef(m[:, 0], m[:, 1])[0, 1]) < 0.1
    assert np.corrcoef(c[:, 0], c[:, 1])[0, 1] > 0.5 * corr_h


def test_fallback_with_few_complete_cases_still_samples():
    human = human_matrix(n=150, missing=0.2)
    assert n_complete_cases(human) < COMPLETE_CASE_MIN
    for baseline in ("copula", "lca"):
        assert generate_baseline(baseline, human, 100, cell_index=0).shape == (100, 10)


def test_cell_seeds_differ():
    seeds = {cell_seed(0, b, i) for b in BASELINES for i in range(5)}
    assert len(seeds) == 3 * 5
