import numpy as np
import pytest

from rcg.calibration import (
    MISSING,
    apply_calibration,
    calibrate,
    calibration_rng,
    learn_calibration_map,
)


def implied_marginal(g_col, rule_map):
    """sum_a p_G(a) M(b | a) as {b: probability}."""
    g = g_col[g_col != MISSING]
    values, counts = np.unique(g, return_counts=True)
    out: dict[int, float] = {}
    for a, c in zip(values, counts, strict=True):
        codes, probs = rule_map[int(a)]
        for b, p in zip(codes, probs, strict=True):
            out[int(b)] = out.get(int(b), 0.0) + c / g.size * p
    return out


@pytest.mark.parametrize("ordered", [True, False])
def test_rules_match_the_human_marginal_exactly(ordered):
    rng = np.random.default_rng(0)
    g = rng.choice([1, 2, 3, 4], size=100, p=[0.1, 0.1, 0.2, 0.6])
    h = rng.choice([0, 1, 2, 3, 4], size=250, p=[0.3, 0.2, 0.2, 0.2, 0.1])
    h[:10] = MISSING
    rule_map = learn_calibration_map(g, h, ordered=ordered)
    assert rule_map is not None
    for _codes, probs in rule_map.values():
        assert probs.sum() == pytest.approx(1.0)
        assert np.all(probs > 0)
    hv, hc = np.unique(h[h != MISSING], return_counts=True)
    target = dict(zip(hv.tolist(), (hc / hc.sum()).tolist(), strict=True))
    got = implied_marginal(g, rule_map)
    assert set(got) == set(target)
    for b, p in target.items():
        assert got[b] == pytest.approx(p)


def test_monotone_rule_for_ordered_items():
    g = np.array([0] * 50 + [1] * 50)
    h = np.array([0] * 25 + [1] * 25 + [2] * 50)
    rule_map = learn_calibration_map(g, h, ordered=True)
    assert rule_map is not None
    # the lower half of G goes to the lower half of H
    np.testing.assert_array_equal(rule_map[0][0], [0, 1])
    np.testing.assert_array_equal(rule_map[1][0], [2])


def test_zero_one_rule_keeps_common_mass():
    g = np.array([1] * 60 + [2] * 40)
    h = np.array([1] * 50 + [2] * 50)
    rule_map = learn_calibration_map(g, h, ordered=False)
    assert rule_map is not None
    codes, probs = rule_map[2]
    np.testing.assert_array_equal(codes, [2])  # deficient answer stays
    codes, probs = rule_map[1]
    assert dict(zip(codes.tolist(), probs.tolist(), strict=True)) == pytest.approx({1: 50 / 60, 2: 10 / 60})


def test_missing_stays_missing_and_unknown_answers_fall_back():
    g_raw = np.array([[1, MISSING], [2, 5], [2, 5]])
    human = np.array([[1, MISSING], [1, MISSING], [2, MISSING]])
    out, n_fallback = calibrate(g_raw, human, ["ordinal", "nominal"], "dm", np.random.default_rng(0))
    assert out[0, 1] == MISSING
    assert n_fallback == 2  # item 2 has no human answer: its two answers are kept
    np.testing.assert_array_equal(out[:, 1], g_raw[:, 1])


def test_streams_depend_on_cell_generator_and_repetition():
    draws = {
        (cell, gen, rep): calibration_rng(0, cell, gen, "dm", rep).random()
        for cell, gen, rep in [(3, "a", 0), (3, "a", 1), (3, "b", 0), (4, "a", 0)]
    }
    assert len(set(draws.values())) == 4
    assert calibration_rng(0, 3, "a", "dm", 0).random() == draws[(3, "a", 0)]


def test_apply_calibration_is_reproducible():
    rng = np.random.default_rng(1)
    g_raw = rng.integers(0, 5, size=(100, 4))
    human = rng.integers(0, 5, size=(150, 4))
    a, _ = calibrate(g_raw, human, ["ordinal"] * 4, "dm", calibration_rng(0, 0, "g", "dm", 0))
    b, _ = calibrate(g_raw, human, ["ordinal"] * 4, "dm", calibration_rng(0, 0, "g", "dm", 0))
    np.testing.assert_array_equal(a, b)
    assert apply_calibration(g_raw, [None] * 4, rng)[1] == g_raw.size
