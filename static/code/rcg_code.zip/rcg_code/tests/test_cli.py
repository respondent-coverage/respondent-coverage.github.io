import importlib.util
from pathlib import Path

import pandas as pd

from rcg.cli import main

EXAMPLE = Path(__file__).resolve().parents[1] / "examples" / "make_toy_data.py"


def load_example():
    spec = importlib.util.spec_from_file_location("make_toy_data", EXAMPLE)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_end_to_end_on_toy_data(tmp_path):
    load_example().make_toy(tmp_path, seed=0)
    inputs = [
        "--schema", str(tmp_path / "schema.jsonl"), "--human", str(tmp_path / "human.jsonl"),
        "--cells", str(tmp_path / "cells.jsonl"),
    ]
    rc = main([
        "baselines", *inputs,
        "--out-dir", str(tmp_path / "gen"), "--baselines", "marginal,copula", "--n-jobs", "1",
    ])
    assert rc == 0
    rc = main([
        "evaluate", *inputs,
        "--generated", f"collapsed={tmp_path / 'generated_collapsed.jsonl'}",
        "--generated", f"shifted={tmp_path / 'generated_shifted.jsonl'}",
        "--generated", f"marginal={tmp_path / 'gen' / 'marginal.jsonl'}",
        "--calibration", "dm", "--n-repeats", "5", "--n-calibration-reps", "2",
        "--out-dir", str(tmp_path / "res"), "--n-jobs", "1",
    ])
    assert rc == 0
    summary = pd.read_csv(tmp_path / "res" / "summary.csv").set_index("generator")
    cells = pd.read_csv(tmp_path / "res" / "cells.csv")
    assert len(cells) == 3 * 4
    assert bool(cells["skipped_reason"].isna().all())
    assert summary.loc["collapsed", "rcg"] > summary.loc["marginal", "rcg"]
    assert summary.loc["shifted", "osr"] > summary.loc["marginal", "osr"]
    assert summary.loc["collapsed", "rcg_dm"] < summary.loc["collapsed", "rcg"]
