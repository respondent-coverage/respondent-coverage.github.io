import numpy as np
import pytest

from rcg.gower import gower_distance, observed_ranges

NAN = np.nan


def test_mixed_types_by_hand():
    col_types = ["ordinal", "numeric", "nominal", "binary_asym"]
    ranges = np.array([4.0, 10.0, NAN, NAN])
    x = np.array([[0.0, 0.0, 1.0, 1.0]])
    y = np.array([[2.0, 10.0, 1.0, 0.0]])
    # ordinal 2/4, numeric 10/10, nominal match 0, binary_asym mismatch 1
    assert gower_distance(x, y, col_types, ranges)[0, 0] == pytest.approx((0.5 + 1.0 + 0.0 + 1.0) / 4)


def test_missing_items_are_skipped_pairwise():
    col_types = ["ordinal", "ordinal", "nominal"]
    ranges = np.array([4.0, 4.0, NAN])
    x = np.array([[0.0, NAN, 1.0]])
    y = np.array([[4.0, 3.0, NAN]])
    # only the first item is answered by both
    assert gower_distance(x, y, col_types, ranges)[0, 0] == pytest.approx(1.0)


def test_no_common_item_gives_nan():
    col_types = ["ordinal", "nominal"]
    ranges = np.array([4.0, NAN])
    x = np.array([[1.0, NAN]])
    y = np.array([[NAN, 2.0]])
    assert np.isnan(gower_distance(x, y, col_types, ranges)[0, 0])


def test_binary_asym_skips_joint_absence():
    col_types = ["binary_asym", "binary_asym"]
    ranges = np.array([NAN, NAN])
    x = np.array([[0.0, 1.0]])
    y = np.array([[0.0, 0.0]])
    # the first item (both absent) is skipped, the second differs
    assert gower_distance(x, y, col_types, ranges)[0, 0] == pytest.approx(1.0)


def test_differences_beyond_the_range_are_clipped():
    x = np.array([[0.0]])
    y = np.array([[9.0]])
    assert gower_distance(x, y, ["numeric"], np.array([3.0]))[0, 0] == 1.0


def test_symmetric_and_zero_on_identical_rows():
    rng = np.random.default_rng(0)
    col_types = ["ordinal"] * 5 + ["nominal"] * 3
    ranges = np.array([4.0] * 5 + [NAN] * 3)
    X = rng.integers(0, 5, size=(20, 8)).astype(float)
    X[rng.random(X.shape) < 0.1] = NAN
    d = gower_distance(X, X, col_types, ranges)
    np.testing.assert_array_equal(d, d.T)
    assert np.all(np.diag(d)[~np.isnan(np.diag(d))] == 0.0)


def test_invalid_ranges_and_types_are_rejected():
    x = np.zeros((1, 2))
    with pytest.raises(ValueError):
        gower_distance(x, x, ["ordinal", "nominal"], np.array([0.0, NAN]))
    with pytest.raises(ValueError):
        gower_distance(x, x, ["ordinal", "interval"], np.array([1.0, NAN]))


def test_observed_ranges():
    X = np.array([[0.0, 1.0, 5.0], [3.0, 1.0, NAN], [NAN, 1.0, 2.0]])
    r = observed_ranges(X, ["ordinal", "numeric", "nominal"])
    assert r[0] == 3.0
    assert r[1] == 1.0  # zero range -> 1.0
    assert np.isnan(r[2])
