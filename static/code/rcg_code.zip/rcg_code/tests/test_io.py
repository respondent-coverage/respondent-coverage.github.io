import json

import numpy as np
import pytest

from rcg.io import (
    MISSING,
    cell_matrices,
    read_cells,
    read_generated,
    read_respondents,
    read_schema,
    write_generated,
)

ITEMS = ["a", "b", "c"]


def write_lines(path, records):
    path.write_text("".join(json.dumps(r) + "\n" for r in records))
    return path


def test_schema(tmp_path):
    path = write_lines(tmp_path / "s.jsonl", [
        {"item": "q1", "type": "ordinal", "range": 4},
        {"item": "q2", "type": "nominal", "range": None},
        {"item": "q3", "type": "numeric"},
    ])
    schema = read_schema(path)
    assert schema.items == ["q1", "q2", "q3"]
    assert list(schema.col_types) == ["ordinal", "nominal", "numeric"]
    assert schema.ranges[0] == 4.0 and np.isnan(schema.ranges[1]) and np.isnan(schema.ranges[2])


def test_human_cells_follow_respondent_ids(tmp_path):
    respondents = write_lines(tmp_path / "h.jsonl", [
        {"respondent_id": "r1", "answers": {"a": 1, "b": None, "c": 3}},
        {"respondent_id": 2, "group": "x", "answers": {"a": 4.0, "c": 6}},  # absent b = missing
        {"respondent_id": "r3", "answers": {}},
    ])
    cells = write_lines(tmp_path / "c.jsonl", [
        {"cell_id": "c2", "respondent_ids": [2, "r1"]},
        {"cell_id": "c1", "respondent_ids": ["r1", "r3"]},
    ])
    human = cell_matrices(read_respondents(respondents, ITEMS), read_cells(cells))
    assert list(human) == ["c2", "c1"]  # file order
    np.testing.assert_array_equal(human["c2"], [[4, MISSING, 6], [1, MISSING, 3]])
    np.testing.assert_array_equal(human["c1"], [[1, MISSING, 3], [MISSING] * 3])


def test_generated_round_trip(tmp_path):
    cells = {"c2": np.array([[1, MISSING, 3], [4, 5, 6]]), "c1": np.array([[7, 8, MISSING]])}
    write_generated(tmp_path / "g.jsonl", cells, ITEMS)
    first = json.loads((tmp_path / "g.jsonl").read_text().splitlines()[0])
    assert first == {"cell_id": "c2", "answers": {"a": 1, "b": None, "c": 3}}
    back = read_generated(tmp_path / "g.jsonl", ITEMS)
    assert list(back) == ["c2", "c1"]  # file order
    for cid, mat in cells.items():
        np.testing.assert_array_equal(back[cid], mat)


@pytest.mark.parametrize(
    ("answers", "message"),
    [
        ({"a": 1, "d": 2}, "not in the schema"),
        ({"a": MISSING}, "reserved"),
        ({"a": 2.5}, "integer code"),
        ({"a": "3"}, "integer code"),
        ({"a": True}, "integer code"),
    ],
)
def test_bad_answers(tmp_path, answers, message):
    path = write_lines(tmp_path / "g.jsonl", [{"cell_id": "c1", "answers": answers}])
    with pytest.raises(ValueError, match=message):
        read_generated(path, ITEMS)


def test_bad_files(tmp_path):
    path = tmp_path / "bad.jsonl"
    path.write_text('{"cell_id": "c1", "answers": {"a": 1}}\n{"cell_id": \n')
    with pytest.raises(ValueError, match=r"bad\.jsonl:2: invalid JSON"):
        read_generated(path, ITEMS)
    path = write_lines(tmp_path / "h.jsonl", [
        {"respondent_id": "r1", "answers": {}},
        {"respondent_id": "r1", "answers": {}},
    ])
    with pytest.raises(ValueError, match="duplicated respondent_id"):
        read_respondents(path, ITEMS)
    path = write_lines(tmp_path / "c.jsonl", [{"cell_id": "c1", "respondent_ids": ["r1", "r1"]}])
    with pytest.raises(ValueError, match="more than once"):
        read_cells(path)
    with pytest.raises(ValueError, match="not in the human respondents file"):
        cell_matrices({"r1": np.zeros(3, dtype=int)}, {"c1": ["r1", "r2"]})
    path = write_lines(tmp_path / "s.jsonl", [{"item": "q1", "type": "ordinal", "range": 0}])
    with pytest.raises(ValueError, match="positive number"):
        read_schema(path)
    path = write_lines(tmp_path / "s.jsonl", [{"item": "q1", "type": "likert"}])
    with pytest.raises(ValueError, match="unknown item type"):
        read_schema(path)
