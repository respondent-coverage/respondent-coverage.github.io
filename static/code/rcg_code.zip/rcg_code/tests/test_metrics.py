import numpy as np
import pytest

from rcg.metrics import MISSING, evaluate_cell, mean_ratio, nn_quantile

D = 12
COL_TYPES = np.asarray(["ordinal"] * 8 + ["nominal"] * 4, dtype=object)
RANGES = np.array([4.0] * 8 + [np.nan] * 4)


def sample(rng, n, p_ordinal=None, missing=0.0):
    out = np.empty((n, D), dtype=int)
    out[:, :8] = rng.choice(5, size=(n, 8), p=p_ordinal)
    out[:, 8:] = rng.integers(1, 5, size=(n, 4))
    out[rng.random(out.shape) < missing] = MISSING
    return out


def test_nn_quantile_ignores_undefined_pairs():
    d = np.array([[np.nan, 0.2], [np.nan, np.nan], [0.4, 0.1]])
    # row NN distances: 0.2, undefined, 0.1 -> quantile over [0.2, 0.1]
    assert nn_quantile(d, axis=1, quantile=1.0) == pytest.approx(0.2)
    assert nn_quantile(d, axis=0, quantile=0.0) == pytest.approx(0.1)


def test_mean_ratio_drops_bad_repetitions():
    mean, _ = mean_ratio([1.0, 2.0, 3.0], [1.0, 0.0, np.nan])
    assert mean == pytest.approx(1.0)
    assert mean_ratio([1.0], [0.0]) == (None, None)


def test_same_distribution_gives_ratios_near_one():
    rng = np.random.default_rng(0)
    human = sample(rng, 400)
    gen = sample(rng, 100)
    res = evaluate_cell(human, {"g": gen}, COL_TYPES, RANGES, cell_index=0, n_repeats=20)["g"]
    assert res["skipped_reason"] == ""
    assert 0.85 < res["rcg"] < 1.15
    assert 0.85 < res["osr"] < 1.15


def test_low_diversity_raises_rcg_but_not_osr():
    rng = np.random.default_rng(1)
    human = sample(rng, 300)
    narrow = np.full((100, D), 2, dtype=int)  # everyone answers the middle option
    narrow[:, 8:] = 1
    res = evaluate_cell(human, {"narrow": narrow}, COL_TYPES, RANGES, cell_index=0, n_repeats=10)
    assert res["narrow"]["rcg"] > 1.5
    assert res["narrow"]["osr"] < 1.0


def test_off_support_raises_osr():
    rng = np.random.default_rng(2)
    p = np.array([0.4, 0.3, 0.2, 0.1, 0.0])  # no human gives the top option
    human = sample(rng, 300, p_ordinal=p)
    off = sample(rng, 100, p_ordinal=p[::-1])
    res = evaluate_cell(human, {"off": off}, COL_TYPES, RANGES, cell_index=0, n_repeats=10)
    assert res["off"]["osr"] > 1.5


def test_reproducible_and_seed_dependent():
    rng = np.random.default_rng(3)
    human = sample(rng, 250, missing=0.05)
    gen = sample(rng, 100)
    kw = {"n_repeats": 5}
    a = evaluate_cell(human, {"g": gen}, COL_TYPES, RANGES, cell_index=4, **kw)["g"]
    b = evaluate_cell(human, {"g": gen}, COL_TYPES, RANGES, cell_index=4, **kw)["g"]
    c = evaluate_cell(human, {"g": gen}, COL_TYPES, RANGES, cell_index=5, **kw)["g"]
    assert a == b
    assert a["rcg"] != c["rcg"]


def test_exactly_fixed_size_humans_is_one_deterministic_repetition():
    rng = np.random.default_rng(4)
    human = sample(rng, 100)
    gen = sample(rng, 100)
    res = evaluate_cell(human, {"g": gen}, COL_TYPES, RANGES, cell_index=0, n_repeats=50)["g"]
    assert res["n_repeats"] == 1


def test_skips():
    rng = np.random.default_rng(5)
    res = evaluate_cell(
        sample(rng, 99), {"g": sample(rng, 100)}, COL_TYPES, RANGES, cell_index=0,
    )
    assert res["g"]["skipped_reason"].startswith("n_human=99")
    res = evaluate_cell(
        sample(rng, 150), {"small": sample(rng, 99), "none": None}, COL_TYPES, RANGES,
        cell_index=0, n_repeats=2,
    )
    assert res["small"]["skipped_reason"].startswith("n_generated=99")
    assert res["none"]["skipped_reason"] == "no generated matrix"


def test_only_first_fixed_size_generated_rows_are_used():
    rng = np.random.default_rng(6)
    human = sample(rng, 200)
    gen = sample(rng, 100)
    extra = np.vstack([gen, sample(rng, 50)])
    a = evaluate_cell(human, {"g": gen}, COL_TYPES, RANGES, cell_index=0, n_repeats=3)["g"]
    b = evaluate_cell(human, {"g": extra}, COL_TYPES, RANGES, cell_index=0, n_repeats=3)["g"]
    assert a["rcg"] == b["rcg"] and a["osr"] == b["osr"]


def test_calibration_removes_marginal_error():
    rng = np.random.default_rng(7)
    human = sample(rng, 300)
    biased = sample(rng, 100, p_ordinal=np.array([0.0, 0.0, 0.1, 0.3, 0.6]))
    res = evaluate_cell(
        human, {"b": biased}, COL_TYPES, RANGES, cell_index=0, n_repeats=5,
        calibration=("dm",), n_calibration_reps=3,
    )["b"]
    assert res["rcg_dm"] < res["rcg"]
    assert res["n_fallback_dm"] == 0
